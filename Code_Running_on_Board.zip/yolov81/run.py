import math
import struct
import subprocess
import sys
import time
from collections import deque
from datetime import datetime

import cv2
from rknn_model import YoloViaRknnModel
from drowy_detection import VideoFrameHandler
import mediapipe as mp
import socket
import numpy as np

from PyQt6 import uic
from PyQt6.QtCore import QThread, pyqtSignal, QTimer, QDateTime
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import QApplication, QMainWindow


#摄像头1，用于检测疲劳和分心行为
class YoloViaRknnThread(QThread):
    change_pixmap_signal = pyqtSignal(QImage)

    drowy_signal = pyqtSignal(bool)
    smoke_signal = pyqtSignal(bool)
    phone_signal = pyqtSignal(bool)
    drink_signal = pyqtSignal(bool)
    fenxin_signal = pyqtSignal(bool)


    def __init__(self):
        super().__init__()
        self.running = True
        self.yolo_via_rknn_model = YoloViaRknnModel()
        self.drowy_detection = VideoFrameHandler()
        self.thresholds = {
            "EAR_THRESH": 0.2,  # 眼睛纵横比阈值，低于此值判定为闭眼
            "WAIT_TIME": 1.0  # 持续闭眼超过3秒触发警报
        }

        self.smoke_action = False
        self.phone_action = False
        self.drink_action = False
        self.fenxin_action = False


    def run(self):
        cap = cv2.VideoCapture(21)

        while self.running:
            ret, frame = cap.read()
            #YOLO进行处理
            yolo_image, smoke_state, phone_state, drink_state = self.yolo_via_rknn_model.process(frame)
            #mediapipe进行处理
            processed_frame, should_alert = self.drowy_detection.process(yolo_image, self.thresholds)


            if smoke_state == "CONFIRMED":
                self.smoke_action = True
            else:
                self.smoke_action = False

            if phone_state == "CONFIRMED":
                self.phone_action = True
            else:
                self.phone_action = False

            if drink_state == "CONFIRMED":
                self.drink_action = True
            else:
                self.drink_action = False

            if smoke_state == "CONFIRMED" or phone_state == "CONFIRMED" or drink_state == "CONFIRMED":
                self.fenxin_action = True
            else:
                self.fenxin_action = False


            self.drowy_signal.emit(should_alert)
            self.fenxin_signal.emit(self.fenxin_action)
            self.smoke_signal.emit(self.smoke_action)
            self.phone_signal.emit(self.phone_action)
            self.drink_signal.emit(self.drink_action)


            rgb_image = cv2.cvtColor(processed_frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            # 将 NumPy 数组转换为 QImage
            qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)  # 修改此处
            # 发送信号，将图像传递给主线程
            self.change_pixmap_signal.emit(qt_image)


            time.sleep(0.01)

        # 释放资源
        cap.release()

    def stop(self):
        self.running = False



#摄像头2，用于监控油箱情况
class TheftDetectionThread(QThread):
    change_pixmap_signal2 = pyqtSignal(QImage)
    theft_singal = pyqtSignal(bool)
    bend_head = pyqtSignal(bool)
    bend_hand = pyqtSignal(bool)
    look_action = pyqtSignal(bool)
    huida_action = pyqtSignal(bool)

    def __init__(self):
        super().__init__()
        self.running = True
        # 加载mediapipe模型
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose()
        self.mp_drawing = mp.solutions.drawing_utils

        self.nose_history = deque(maxlen=10)
        self.left_wrist_y_history = deque(maxlen=10)
        self.right_wrist_y_history = deque(maxlen=10)


        self.temp1 = 0
        self.temp2 = 0
        self.temp3 = 0
        self.temp4 = 0

        self.temp1_flag = False
        self.temp2_flag = False
        self.temp3_flag = False
        self.temp4_flag = False

    def run(self):
        cap = cv2.VideoCapture(11)


        while self.running:
            ret, frame = cap.read()
            if not ret:
                break

            image = cv2.cvtColor(frame.copy(), cv2.COLOR_BGR2RGB)
            results = self.pose.process(image)

            # 初始化行为状态
            behavior_status = {}

            if results.pose_landmarks:
                self.mp_drawing.draw_landmarks(frame, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)
                behavior_status = self.detect_behaviors(results.pose_landmarks)   #检测动作的函数


            if "bend_over_and_reach_hand" in behavior_status:
                self.temp1 += 1
            else:
                self.temp1 = 0

            if "bend_over_and_bow_head" in behavior_status:
                self.temp2 += 1
            else:
                self.temp2 = 0

            if "look_left_and_right" in behavior_status:
                self.temp3 += 1
            else:
                self.temp3 = 0

            if "repeat_swing_action" in behavior_status:
                self.temp4 += 1
            else:
                self.temp4 = 0


            if self.temp1 >= 10:
                self.temp1_flag = True
            else:
                self.temp1_flag = False

            if self.temp2 >= 10:
                self.temp2_flag = True
            else:
                self.temp2_flag = False

            if self.temp3 >= 3:
                self.temp3_flag = True
            else:
                self.temp3_flag = False

            if self.temp4 >= 3:
                self.temp4_flag = True
            else:
                self.temp4_flag = False


            if self.temp1_flag or self.temp2_flag or self.temp3_flag or self.temp4_flag:
                self.theft_singal.emit(True)
            else:
                self.theft_singal.emit(False)


            self.bend_hand.emit(self.temp1)
            self.bend_head.emit(self.temp2)
            self.look_action.emit(self.temp3)
            self.huida_action.emit(self.temp4)


            # 在图像上绘制检测信息（总是绘制）
            frame = self.draw_detection_info(frame, behavior_status)

            rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            # 将 NumPy 数组转换为 QImage
            qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)  # 修改此处
            # 发送信号，将图像传递给主线程
            self.change_pixmap_signal2.emit(qt_image)

            # 控制帧率（如 30 FPS）
            time.sleep(0.01)

        cap.release()


    def stop(self):
        self.running = False


    def detect_behaviors(self, landmarks):
        status = {}
        get = lambda name: landmarks.landmark[self.mp_pose.PoseLandmark[name]]
        nose = get("NOSE")
        left_shoulder = get("LEFT_SHOULDER")
        right_shoulder = get("RIGHT_SHOULDER")
        left_hip = get("LEFT_HIP")
        right_hip = get("RIGHT_HIP")
        left_knee = get("LEFT_KNEE")
        right_knee = get("RIGHT_KNEE")
        left_wrist = get("LEFT_WRIST")
        right_wrist = get("RIGHT_WRIST")

        shoulder_y = (left_shoulder.y + right_shoulder.y) / 2  # 肩膀的平均高度
        hip_y = (left_hip.y + right_hip.y) / 2  # 双髋的平均高度

        # 计算多个指标
        spine_angle = self.calculate_angle(left_shoulder, left_hip, left_knee)
        shoulder_hip_diff = shoulder_y - hip_y
        wrist_extended = min(left_wrist.y, right_wrist.y) > (hip_y + 0.05)

        # 改进后的动作检测
        bend_reach_condition = (
                (spine_angle < 160 or shoulder_hip_diff > 0.03)
                and wrist_extended
                and not (nose.y > shoulder_y + 0.1)  # 防止低头误判
        )

        bow_head_condition = (
                (nose.y > shoulder_y + 0.1)  # 更强的低头条件
                and abs(nose.y - hip_y) < 0.15  # 更严格的头部-髋部接近条件
                and not wrist_extended  # 排除伸手情况
        )

        # 互斥判断逻辑
        if bend_reach_condition:
            status["bend_over_and_reach_hand"] = True
        elif bow_head_condition:
            status["bend_over_and_bow_head"] = True
        else:
            print("动作未识别到")

        # 左顾右盼检测
        self.nose_history.append(nose.x)
        if len(self.nose_history) >= 5:
            delta = max(self.nose_history) - min(self.nose_history)
            if delta > 0.08:
                status["look_left_and_right"] = True

        # 重复挥打检测
        self.left_wrist_y_history.append(left_wrist.y)
        self.right_wrist_y_history.append(right_wrist.y)

        def is_waving(history):
            if len(history) < 5:
                return False
            diffs = [abs(history[i] - history[i - 1]) for i in range(1, len(history))]
            return sum(d > 0.04 for d in diffs) >= 3

        if is_waving(self.left_wrist_y_history) or is_waving(self.right_wrist_y_history):
            status["repeat_swing_action"] = True

        return status


    def draw_detection_info(self, frame, detection_data):
        """在图像上显示检测信息（简化版）

        参数:
            frame: 要绘制的图像
            detection_data: 包含检测信息的字典，格式为 {键: 值}
        """
        # 1. 基础信息（相机标识）
        cv2.putText(frame, "Camera: 2", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)

        # 2. 显示检测信息（从顶部开始）
        y_pos = 60  # 起始Y位置
        for key, value in detection_data.items():
            # 格式化键值对
            text = f"{key}: {value}"
            # 在图像上绘制文本
            cv2.putText(frame, text, (10, y_pos),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 1)
            y_pos += 30  # 下移一行

        # 3. 添加时间戳
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cv2.putText(frame, timestamp, (frame.shape[1] - 250, frame.shape[0] - 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

        return frame

    def calculate_angle(self, a, b, c):
        # 计算三个点之间的角度
        ba = [a.x - b.x, a.y - b.y]
        bc = [c.x - b.x, c.y - b.y]
        cosine_angle = (ba[0] * bc[0] + ba[1] * bc[1]) / (
                    math.sqrt(ba[0] ** 2 + ba[1] ** 2) * math.sqrt(bc[0] ** 2 + bc[1] ** 2))
        angle = math.degrees(math.acos(cosine_angle))
        return angle


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = uic.loadUi("mywindow.ui")  # 加载QT中设计好的UI界面
        self.camera1 = self.ui.camera1       # 驾驶室画面，检测疲劳
        self.camera2 = self.ui.camera2       # 油箱画面，检测其他行为
        self.serial_box = self.ui.serial_box # 给串口添加串口号
        self.drowsy_red = self.ui.drowsy_red     #疲劳检测的红灯
        self.drowsy_green = self.ui.drowsy_green #疲劳检测的绿灯
        self.distract_red = self.ui.distract_red
        self.distract_green = self.ui.distract_green
        self.oil_red = self.ui.oil_red
        self.oil_green = self.ui.oil_green
        self.now_time = self.ui.now_time

        self.serial_box.addItem("COM1")
        self.serial_box.addItem("COM2")
        self.serial_box.addItem("COM3")
        self.serial_box.addItem("COM4")
        self.serial_box.addItem("COM5")

        self.host = "192.168.3.3"
        self.port = 12345
        self.addr = (self.host, self.port)
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client.connect(self.addr)
        print(f"✅ Successfully connected to the server: {self.addr}")

        self.distract_red_to_green()
        self.distract_red_to_green()
        self.oil_red_to_green()

        self.now_time.setStyleSheet("""color: red;font-size:40px;""")
        # 创建 QTimer，每 1 秒更新一次时间
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_time)
        self.timer.start(1000)  # 1000ms = 1s
        # 立即更新时间
        self.update_time()
###################################################################################################################

        self.drowsy_cool_time = 0
        self.smoke_cool_time = 0
        self.phone_cool_time = 0
        self.drink_cool_time = 0

        self.bend_hand_cool_time = 0
        self.bend_head_cool_time = 0
        self.look_action_cool_time = 0
        self.huida_action_cool_time = 0


        self.temp_image1 = None
        self.temp_image2 = None


        self.my_yolo_rknn_thread = YoloViaRknnThread()             #线程1，检测疲劳驾驶
        self.theft_detection_thread = TheftDetectionThread()       #线程2，检测偷油
        # 连接信号和槽
        self.my_yolo_rknn_thread.change_pixmap_signal.connect(self.show_camera1)

        self.my_yolo_rknn_thread.drowy_signal.connect(self.drowsy_func)
        self.my_yolo_rknn_thread.fenxin_signal.connect(self.fenxin_func)
        self.my_yolo_rknn_thread.smoke_signal.connect(self.smoke_func)
        self.my_yolo_rknn_thread.phone_signal.connect(self.phone_func)
        self.my_yolo_rknn_thread.drink_signal.connect(self.drink_func)


        self.theft_detection_thread.change_pixmap_signal2.connect(self.show_camera2)

        self.theft_detection_thread.theft_singal.connect(self.theft_func)
        self.theft_detection_thread.bend_hand.connect(self.bend_hand_func)
        self.theft_detection_thread.bend_head.connect(self.bend_head_func)
        self.theft_detection_thread.look_action.connect(self.look_action_func)
        self.theft_detection_thread.huida_action.connect(self.huida_action_func)

        # 启动线程
        self.my_yolo_rknn_thread.start()
        self.theft_detection_thread.start()


    def smoke_func(self, flag):
        temp_now_time = time.time()
        if temp_now_time > self.smoke_cool_time:
            if flag:
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image1), 1, 2)
                self.smoke_cool_time = temp_now_time + 5
        else:
            return


    def phone_func(self, flag):
        temp_now_time = time.time()
        if temp_now_time > self.phone_cool_time:
            if flag:
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image1), 1, 3)
                self.phone_cool_time = temp_now_time + 5
        else:
            return

    
    def drink_func(self, flag):
        temp_now_time = time.time()
        if temp_now_time > self.drink_cool_time:
            if flag:
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image1), 1, 4)
                self.drink_cool_time = temp_now_time + 5
        else:
            return


    def show_camera1(self, qt_image):
        # 将捕获到的 QImage 设置到 QLabel 上显示
        self.camera1.setPixmap(QPixmap.fromImage(qt_image))
        # 启用图片自适应 QLabel 大小
        self.camera1.setScaledContents(True)
        self.temp_image1 = qt_image

    def show_camera2(self, qt_image):
        # 将捕获到的 QImage 设置到 QLabel 上显示
        self.camera2.setPixmap(QPixmap.fromImage(qt_image))
        # 启用图片自适应 QLabel 大小
        self.camera2.setScaledContents(True)
        self.temp_image2 = qt_image


    def update_time(self):
        # 获取当前时间并格式化
        current_time = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        self.now_time.setText(current_time)

    def drowsy_func(self, my_singal):
        temp_current_time = time.time()
        if my_singal:
            self.drowsy_green_to_red()
            self.play_mp3_func("./video/pilao.mp3")
            #播报语音警告
        else:
            self.drowsy_red_to_green()

        if temp_current_time > self.drowsy_cool_time:
            if my_singal:
                #向PC端通过TCP发送图片
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image1), 1, 1)
                self.drowsy_cool_time = temp_current_time + 5
        else:
            return


    def fenxin_func(self, flag):
        if flag:
            self.distract_green_to_red()
            self.play_mp3_func("./video/fenxin.mp3")
        else:
            self.distract_red_to_green()


    def theft_func(self, my_singal):
        if my_singal:
            self.oil_green_to_red()
            self.play_mp3_func("./video/touyou.mp3")
        else:
            self.oil_red_to_green()


    def bend_hand_func(self, flag):
        temp_current_time = time.time()
        if temp_current_time > self.bend_hand_cool_time:
            if flag:
                #向PC端通过TCP发送图片
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image2), 2, 1)
                self.bend_hand_cool_time = temp_current_time + 5
        else:
            return

    def bend_head_func(self, flag):
        temp_current_time = time.time()
        if temp_current_time > self.bend_head_cool_time:
            if flag:
                #向PC端通过TCP发送图片
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image2), 2, 2)
                self.bend_head_cool_time = temp_current_time + 5
        else:
            return

    def look_action_func(self, flag):
        temp_current_time = time.time()
        if temp_current_time > self.look_action_cool_time:
            if flag:
                #向PC端通过TCP发送图片
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image2), 2, 3)
                self.look_action_cool_time = temp_current_time + 5
        else:
            return

    def huida_action_func(self, flag):
        temp_current_time = time.time()
        if temp_current_time > self.huida_action_cool_time:
            if flag:
                #向PC端通过TCP发送图片
                self.send_image_via_tcp(self.qimage_to_cv(self.temp_image2), 2, 4)
                self.huida_action_cool_time = temp_current_time + 5
        else:
            return
        
    def qimage_to_cv(self, qt_image):
        qt_image = qt_image.convertToFormat(QImage.Format.Format_RGB888)
        width = qt_image.width()
        height = qt_image.height()

        ptr = qt_image.constBits()
        ptr.setsize(qt_image.sizeInBytes())

        arr = np.array(ptr).reshape(height, width, 3)

        cv_image = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)

        return cv_image


    def send_image_via_tcp(self, image, image_type, action_flags):
        _, buffer = cv2.imencode('.jpg', image)
        img_bytes = buffer.tobytes()

        # 2. 发送元数据 (摄像头ID和行为代码)
        meta_data = struct.pack('!ii', image_type, action_flags)
        self.client.sendall(meta_data)

        # 3. 发送图像大小和图像数据
        img_size = struct.pack('!I', len(img_bytes))
        self.client.sendall(img_size + img_bytes)


    def play_mp3_func(self, file_path):
        try:
            subprocess.Popen(["ffplay", "-nodisp", "-autoexit", "-volume", "256", file_path])
            print("播放启动")
        except FileNotFoundError:
            print("请检查路径")


    def drowsy_green_to_red(self):
        self.drowsy_red.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: red;""")
        self.drowsy_green.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: white;""")

    def drowsy_red_to_green(self):
        self.drowsy_red.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: white;""")
        self.drowsy_green.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: green;""")

    def distract_green_to_red(self):
        self.distract_red.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: red;""")
        self.distract_green.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: white;""")

    def distract_red_to_green(self):
        self.distract_red.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: white;""")
        self.distract_green.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: green;""")

    def oil_green_to_red(self):
        self.oil_red.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: red;""")
        self.oil_green.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: white;""")

    def oil_red_to_green(self):
        self.oil_red.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: white;""")
        self.oil_green.setStyleSheet("""
                    border: 1px solid black;
                    border-radius: 15px;
                    min-width: 30px;
                    min-height: 30px;
                    max-width: 30px;
                    max-height: 30px;
                    background-color: green;""")


    ######关闭UI界面的响应函数######
    def closeEvent(self, event):
        # 关闭时停止视频线程
        self.my_yolo_rknn_thread.stop()
        self.theft_detection_thread.stop()
        self.timer.stop()
        event.accept()


if __name__ == "__main__":

    app = QApplication(sys.argv)
    mywindow = MainWindow()
    mywindow.ui.show()
    sys.exit(app.exec())


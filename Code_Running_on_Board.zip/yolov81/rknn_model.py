import copy

import cv2
from rknnlite.api import RKNNLite
import numpy as np

#指定加载RKNN模型的位置
RKNN_MODEL = "./yolov8.rknn"

#模型检测的类别
CLASSES = ['face','smoke','phone','drink']

OBJ_THRESH = 0.25  #过滤掉低置信度的检测框（减少误检）
NMS_THRESH = 0.45  #合并高度重叠的检测框（避免重复检测）------值越小，NMS越严格（保留的框越少）；值越大，NMS越宽松（保留的框越多）

MODEL_SIZE = (640, 640)  #模型的尺寸，宽*高==640*640

#为每个检测类别随机生成一种 BGR 颜色（用于可视化检测结果）
color_palette = np.random.uniform(0, 255, size=(len(CLASSES), 3))

#将任意实数 x 映射到 (0, 1) 范围内进行归一化，方便后续进行操作
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

#将输入图像按比例缩放到目标尺寸 new_shape，并在周围填充指定颜色（默认黑色），同时保持原始图像的宽高比不变。
def letter_box(im, new_shape, pad_color=(0, 0, 0), info_need=False):
    # Resize and pad image while meeting stride-multiple constraints
    shape = im.shape[:2]  # current shape [height, width]
    # 若为整数，转为正方形（如 640 → (640,640)）
    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)   #宽*高

    # Scale ratio  缩放比例，取最小比例，确保图像完全放入目标尺寸
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])

    # Compute padding
    ratio = r  # width, height ratios
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding

    dw /= 2  # divide padding into 2 sides
    dh /= 2

    if shape[::-1] != new_unpad:  # resize
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=pad_color)  # add border

    if info_need is True:
        return im, ratio, (dw, dh)
    else:
        return im    #返回缩放后的图像

#用于过滤低置信度检测框
def filter_boxes(boxes, box_confidences, box_class_probs):
    """Filter boxes with object threshold.
    """
    box_confidences = box_confidences.reshape(-1)
    candidate, class_num = box_class_probs.shape

    class_max_score = np.max(box_class_probs, axis=-1)
    classes = np.argmax(box_class_probs, axis=-1)

    _class_pos = np.where(class_max_score * box_confidences >= OBJ_THRESH)
    scores = (class_max_score * box_confidences)[_class_pos]

    boxes = boxes[_class_pos]
    classes = classes[_class_pos]

    return boxes, classes, scores

#去除高度重叠的冗余检测框，保留置信度最高的框
def nms_boxes(boxes, scores):
    """Suppress non-maximal boxes.
    # Returns
        keep: ndarray, index of effective boxes.
    """
    x = boxes[:, 0]
    y = boxes[:, 1]
    w = boxes[:, 2] - boxes[:, 0]
    h = boxes[:, 3] - boxes[:, 1]

    areas = w * h
    order = scores.argsort()[::-1]

    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)

        xx1 = np.maximum(x[i], x[order[1:]])
        yy1 = np.maximum(y[i], y[order[1:]])
        xx2 = np.minimum(x[i] + w[i], x[order[1:]] + w[order[1:]])
        yy2 = np.minimum(y[i] + h[i], y[order[1:]] + h[order[1:]])

        w1 = np.maximum(0.0, xx2 - xx1 + 0.00001)
        h1 = np.maximum(0.0, yy2 - yy1 + 0.00001)
        inter = w1 * h1

        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        inds = np.where(ovr <= NMS_THRESH)[0]
        order = order[inds + 1]
    keep = np.array(keep)
    return keep

def softmax(x, axis=None):
    x = x - x.max(axis=axis, keepdims=True)
    y = np.exp(x)
    return y / y.sum(axis=axis, keepdims=True)

#DFL 的核心思想是将边界框坐标的预测建模为离散概率分布，而不是直接回归连续值。这种方法能更精确地定位物体，特别是对小物体效果显著。
def dfl(position):
    # Distribution Focal Loss (DFL)
    n, c, h, w = position.shape
    p_num = 4
    mc = c // p_num
    y = position.reshape(n, p_num, mc, h, w)
    y = softmax(y, 2)
    acc_metrix = np.array(range(mc), dtype=float).reshape(1, 1, mc, 1, 1)
    y = (y * acc_metrix).sum(2)
    return y

#用于将模型输出的边界框位置信息转换为实际坐标的关键函数
def box_process(position):
    grid_h, grid_w = position.shape[2:4]
    col, row = np.meshgrid(np.arange(0, grid_w), np.arange(0, grid_h))
    col = col.reshape(1, 1, grid_h, grid_w)
    row = row.reshape(1, 1, grid_h, grid_w)
    grid = np.concatenate((col, row), axis=1)
    stride = np.array([MODEL_SIZE[1] // grid_h, MODEL_SIZE[0] // grid_w]).reshape(1, 2, 1, 1)

    position = dfl(position)
    box_xy = grid + 0.5 - position[:, 0:2, :, :]
    box_xy2 = grid + 0.5 + position[:, 2:4, :, :]
    xyxy = np.concatenate((box_xy * stride, box_xy2 * stride), axis=1)

    return xyxy

#后处理部分，将模型原始输出转换为最终的检测结果（边界框、类别、置信度）
def post_process(input_data):
    boxes, scores, classes_conf = [], [], []
    defualt_branch = 3
    pair_per_branch = len(input_data) // defualt_branch
    # Python 忽略 score_sum 输出
    for i in range(defualt_branch):
        boxes.append(box_process(input_data[pair_per_branch * i]))
        classes_conf.append(input_data[pair_per_branch * i + 1])
        scores.append(np.ones_like(input_data[pair_per_branch * i + 1][:, :1, :, :], dtype=np.float32))

    def sp_flatten(_in):
        ch = _in.shape[1]
        _in = _in.transpose(0, 2, 3, 1)
        return _in.reshape(-1, ch)

    boxes = [sp_flatten(_v) for _v in boxes]
    classes_conf = [sp_flatten(_v) for _v in classes_conf]
    scores = [sp_flatten(_v) for _v in scores]

    boxes = np.concatenate(boxes)
    classes_conf = np.concatenate(classes_conf)
    scores = np.concatenate(scores)

    # filter according to threshold
    boxes, classes, scores = filter_boxes(boxes, scores, classes_conf)

    # nms
    nboxes, nclasses, nscores = [], [], []
    for c in set(classes):
        inds = np.where(classes == c)
        b = boxes[inds]
        c = classes[inds]
        s = scores[inds]
        keep = nms_boxes(b, s)

        if len(keep) != 0:
            nboxes.append(b[keep])
            nclasses.append(c[keep])
            nscores.append(s[keep])

    if not nclasses and not nscores:
        return None, None, None

    boxes = np.concatenate(nboxes)
    classes = np.concatenate(nclasses)
    scores = np.concatenate(nscores)

    return boxes, classes, scores

# #目标检测结果的可视化函数，用于在图像上绘制检测到的物体边界框和相关信息
# def draw_detections(img, left, top, right, bottom, score, class_id):
#     """
#     Draws bounding boxes and labels on the input image based on the detected objects.
#     Args:
#         img: The input image to draw detections on.
#         box: Detected bounding box.
#         score: Corresponding detection score.
#         class_id: Class ID for the detected object.
#     Returns:
#         None
#     """
#
#     # Retrieve the color for the class ID
#     color = color_palette[class_id]
#
#     # Draw the bounding box on the image
#     cv2.rectangle(img, (int(left), int(top)), (int(right), int(bottom)), color, 2)
#
#     # Create the label text with class name and score
#     label = f"{CLASSES[class_id]}: {score:.2f}"
#
#     # Calculate the dimensions of the label text
#     (label_width, label_height), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
#
#     # Calculate the position of the label text
#     label_x = left
#     label_y = top - 10 if top - 10 > label_height else top + 10
#
#     # Draw a filled rectangle as the background for the label text
#     cv2.rectangle(img, (label_x, label_y - label_height), (label_x + label_width, label_y + label_height), color,
#                   cv2.FILLED)
#
#     # Draw the label text on the image
#     cv2.putText(img, label, (label_x, label_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)
#
# #绘制图像
# def draw(image, boxes, scores, classes):
#     img_h, img_w = image.shape[:2]
#     # Calculate scaling factors for bounding box coordinates
#     x_factor = img_w / MODEL_SIZE[0]
#     y_factor = img_h / MODEL_SIZE[1]
#
#     for box, score, cl in zip(boxes, scores, classes):
#         x1, y1, x2, y2 = [int(_b) for _b in box]
#
#         left = int(x1 * x_factor)
#         top = int(y1 * y_factor)
#         right = int(x2 * x_factor)
#         bottom = int(y2 * y_factor)
#
#         print('class: {}, score: {}'.format(CLASSES[cl], score))
#         print('box coordinate left,top,right,down: [{}, {}, {}, {}]'.format(left, top, right, bottom))
#
#         # Retrieve the color for the class ID
#
#         draw_detections(image, left, top, right, bottom, score, cl)
#
#         # cv2.rectangle(image, (left, top), (right, bottom), color, 2)
#         # cv2.putText(image, '{0} {1:.2f}'.format(CLASSES[cl], score),
#         #             (left, top - 6),
#         #             cv2.FONT_HERSHEY_SIMPLEX,
#         #             0.6, (0, 0, 255), 2)

def draw_detections(image, boxes, scores, classes):
    """
    在图像上绘制检测框和类别信息
    Args:
        image: 输入图像 (numpy数组)
        boxes: 检测框坐标列表 [[x1,y1,x2,y2], ...]
        scores: 置信度列表 [score1, score2, ...]
        classes: 类别ID列表 [class_id1, class_id2, ...]
    Returns:
        绘制后的图像
    """

    img_copy = copy.deepcopy(image)
    img_h, img_w = img_copy.shape[:2]

    # 计算坐标缩放因子
    x_scale = img_w / MODEL_SIZE[0]
    y_scale = img_h / MODEL_SIZE[1]

    for box, score, class_id in zip(boxes, scores, classes):
        # 坐标转换
        x1, y1, x2, y2 = [int(coord) for coord in box]
        left = int(x1 * x_scale)
        top = int(y1 * y_scale)
        right = int(x2 * x_scale)
        bottom = int(y2 * y_scale)

        # 获取类别颜色
        color = color_palette[class_id]

        # 绘制边界框
        cv2.rectangle(img_copy, (left, top), (right, bottom), color, 2)

        # 准备标签文本
        label = f"{CLASSES[class_id]}: {score:.2f}"

        # 计算文本尺寸
        (label_width, label_height), _ = cv2.getTextSize(
            label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)

        # 计算标签位置
        label_x = left
        label_y = bottom + label_height + 5  # 在底部下方留5像素的间距

        # 确保标签不会超出图像底部边界
        if label_y + label_height > img_h:
            label_y = bottom - label_height - 5  # 如果超出，就放在边界框内部上方

        # 绘制标签背景
        cv2.rectangle(img_copy,
                      (label_x, label_y - label_height),
                      (label_x + label_width, label_y + label_height),
                      color, cv2.FILLED)

        # 绘制标签文本
        cv2.putText(img_copy, label, (label_x, label_y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1, cv2.LINE_AA)

        # 打印检测信息（可选）
        print(f"class: {CLASSES[class_id]}, score: {score:.2f}")
        print(f"box coordinates: [{left}, {top}, {right}, {bottom}]")

    return img_copy


class YoloViaRknnModel:
    def __init__(self):
        # 创建RKNN对象
        self.rknn_lite = RKNNLite()

        # 加载RKNN模型
        print('--> Load RKNN model')
        ret = self.rknn_lite.load_rknn(RKNN_MODEL)
        if ret != 0:
            print('Load RKNN model failed')
            exit(ret)
        print('done')

        # 初始化 runtime 环境
        print('--> Init runtime environment')
        # run on RK356x/RK3588 with Debian OS, do not need specify target.
        ret = self.rknn_lite.init_runtime()
        if ret != 0:
            print('Init runtime environment failed!')
            exit(ret)
        print('done')

        self.smoke_flag = False
        self.phone_flag = False
        self.drink_flag = False

        self.smoke_state = "UNSEEN"
        self.phone_state = "UNSEEN"
        self.drink_state = "UNSEEN"
        self.smoke_detected_count = 0
        self.phone_detected_count = 0
        self.drink_detected_count = 0
        self.smoke_missed_count = 0
        self.phone_missed_count = 0
        self.drink_missed_count = 0

    def process(self, frame: np.array):
        # 预处理（保持模型输入640x640）
        img_input = letter_box(im=frame.copy(), new_shape=(MODEL_SIZE[1], MODEL_SIZE[0]))
        my_input = np.expand_dims(img_input, axis=0)

        # 推理和后处理
        outputs = self.rknn_lite.inference([my_input])
        boxes, classes, scores = post_process(outputs)

        vis_img = frame.copy()
        # 检查是否有检测结果
        if boxes is not None:
            # 遍历每个检测到的物体
            for i, class_id in enumerate(classes):
                # 根据类别进行不同的处理
                if class_id == CLASSES.index('smoke'):  # 检测到吸烟
                    self.smoke_flag = True
                else:
                    self.smoke_flag = False

                if class_id == CLASSES.index('drink'):  # 检测到喝水
                    self.drink_flag = True
                else:
                    self.drink_flag = False

                if class_id == CLASSES.index('phone'):  # 检测到打电话
                    self.phone_flag = True
                else:
                    self.phone_flag = False

                if class_id == CLASSES.index('face'):  # 检测到人脸
                    # 可以正常处理，不输出警告
                    pass
                # 绘制检测结果
                vis_img = draw_detections(vis_img, boxes, scores, classes)
        else:
            self.smoke_flag = False
            self.phone_flag = False
            self.drink_flag = False

        self.update_func(self.smoke_flag, self.phone_flag, self.drink_flag)

        return vis_img, self.smoke_state, self.phone_state, self.drink_state



    def update_func(self, smoke_flag, phone_flag, drink_flag):
        if smoke_flag:
            self.smoke_missed_count = 0
            self.smoke_detected_count += 1
        else:
            self.smoke_missed_count += 1
            self.smoke_detected_count = 0

        if phone_flag:
            self.phone_missed_count = 0
            self.phone_detected_count += 1
        else:
            self.phone_missed_count += 1
            self.phone_detected_count = 0

        if drink_flag:
            self.drink_missed_count = 0
            self.drink_detected_count += 1
        else:
            self.drink_missed_count += 1
            self.drink_detected_count = 0


        if self.smoke_state == "UNSEEN" and smoke_flag:
            self.smoke_state = "POSSIBLE"
        elif self.smoke_state == "POSSIBLE":
            if self.smoke_detected_count >= 3:
                self.smoke_state = "CONFIRMED"
            elif self.smoke_missed_count > 0:
                self.smoke_state = "UNSEEN"
        elif self.smoke_state == "CONFIRMED":
            if self.smoke_missed_count >= 3:
                self.smoke_state = "LOST"
        elif self.smoke_state == "LOST":
            if smoke_flag:
                self.smoke_state = "POSSIBLE"
            elif self.smoke_missed_count > 3:
                self.smoke_state = "UNSEEN"

        if self.phone_state == "UNSEEN" and phone_flag:
            self.phone_state = "POSSIBLE"
        elif self.phone_state == "POSSIBLE":
            if self.phone_detected_count >= 3:
                self.phone_state = "CONFIRMED"
            elif self.phone_missed_count > 0:
                self.phone_state = "UNSEEN"
        elif self.phone_state == "CONFIRMED":
            if self.phone_missed_count >= 3:
                self.phone_state = "LOST"
        elif self.phone_state == "LOST":
            if phone_flag:
                self.phone_state = "POSSIBLE"
            elif self.phone_missed_count > 3:
                self.phone_state = "UNSEEN"

        if self.drink_state == "UNSEEN" and drink_flag:
            self.drink_state = "POSSIBLE"
        elif self.drink_state == "POSSIBLE":
            if self.drink_detected_count >= 3:
                self.drink_state = "CONFIRMED"
            elif self.drink_missed_count > 0:
                self.drink_state = "UNSEEN"
        elif self.drink_state == "CONFIRMED":
            if self.drink_missed_count >= 3:
                self.drink_state = "LOST"
        elif self.drink_state == "LOST":
            if drink_flag:
                self.drink_state = "POSSIBLE"
            elif self.drink_missed_count > 3:
                self.drink_state = "UNSEEN"


import pyttsx3

engine = pyttsx3.init()  # 初始化引擎
engine.save_to_file("开车请勿分心", "./video/fenxin.mp3")  # 保存为音频文件
engine.save_to_file("警告，警告，疲劳驾驶，请立即停车", "./video/pilao.mp3")  # 保存为音频文件
engine.save_to_file("警告，警告，有人靠近油箱，请进行确认", "./video/touyou.mp3")  # 保存为音频文件

engine.runAndWait()  # 等待语音生成完成




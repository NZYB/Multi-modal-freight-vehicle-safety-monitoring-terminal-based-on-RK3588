#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QValueAxis>
#include <QMainWindow>
#include <QSplineSeries>
#include <QTcpServer>
#include <QTcpSocket>
//#include "qcustomplot.h"
#include <QtCharts>
#include <QMap>
#include <QDateTime>


// 不要写 using namespace
namespace QtCharts {
    class QChart;
    class QBarSet;
}

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE



class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;


    // 图像数据缓存
    QMap<QTcpSocket*, QByteArray> imageBuffers;
    QMap<QTcpSocket*, int> imageSizes;
    QMap<QTcpSocket*, uchar> imageActions;  // 新增：动作标志位

    QTcpServer *imageServer;
    QTcpServer *bioServer;
    QList<QTcpSocket*> imageClients;
    QList<QTcpSocket*> bioClients;



    QSplineSeries *redSeries,*irSeries, *tempSeries, *prSeries, *spo2Series, *xinlvSeries;;
    QValueAxis    *axisX;
    QValueAxis    *axisY;
    QChart *redChart, *irChart, *tempChart, *prChart, *spo2Chart, *xinlvChart;
    const double sampleInterval = 0.2;  // 每个数据点时间间隔（秒）
    int sampleCount = 0;
    QChart* createCharts(QSplineSeries *series, const QString &title, const QString &unit, double yMin, double yMax, const QColor &color);
    void createAllCharts();


    int connected_Num;

    QMap<QTcpSocket*, QTimer*> heartbeatTimers;
    const int heartbeatIntervalMs = 50000;
    const int heartbeatTimeoutMs = 100000;

    QMap<QTcpSocket*, uchar> imageTypes;  // 图像类型记录

    QTimer *current_time;      // 定时器对象

    QtCharts::QBarSet *set;

    QTimer* actionTimer;
    int currentActionIndex;
    QList<QLineEdit*> actionLineEdits;



private slots:
    //void readyRead_Slot();
    void on_TCP_Button_clicked();
    //void handleClientRead(QTcpSocket* socket);
    QString getLocalIPv4();
    void updateTime();  // 每秒更新时间的槽函数
    void updateConnectedNum();
    void drawBarChartFromLabels();
    //void updateNextActionCount();

    void newImageConnection();
    void newBioConnection();
    void on_pushButton_clicked();  // 清空所有数据和图像
    //void handleImageData();
    //void handleBioData();


};
#endif // MAINWINDOW_H

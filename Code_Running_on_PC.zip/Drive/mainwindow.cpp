#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLineSeries>
#include <QGraphicsLayout>
#include <QTimer>
#include <QCategoryAxis>
#include <QColorDialog>
#include <QNetworkInterface>
#include <algorithm>

const double sampleInterval = 0.2; // 每个数据点间隔 0.2 秒（即每秒 5 个点）
static int sampleCount = 0;
double timeSec;


struct ImagePacket {
    int stage = 0;             // 0: 等待元数据, 1: 等待图像大小, 2: 等待图像数据
    int imageType = 0;
    int actionFlags = 0;
    int imageSize = 0;
    QByteArray buffer;
};

QMap<QTcpSocket*, ImagePacket> imagePackets;
QMap<QTcpSocket*, QByteArray> socketBuffers;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    ui->label_Time->setStyleSheet("color: blue;");
    current_time = new QTimer(this);
    connect(current_time, &QTimer::timeout, this, &MainWindow::updateTime);
    current_time->start(1000);  // 每1000毫秒触发一次
    qApp->setStyleSheet("QGroupBox { border: 1px solid black; border-radius: 5px; margin-top: 10px; }"
                        "QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 3px 0 3px; }");

    actionLineEdits = {
        ui->lineEdit_fatugi,
        ui->lineEdit_ph,
        ui->lineEdit_smok,
        ui->lineEdit_drink,
        ui->lineEdit_ws,
        ui->lineEdit_wd,
        ui->lineEdit_zg,
        ui->lineEdit_jd
    };

    currentActionIndex = 0;

    /*// 创建定时器
    actionTimer = new QTimer(this);
    connect(actionTimer, &QTimer::timeout, this, &MainWindow::updateNextActionCount);
    actionTimer->start(7000); */ // 每 7 秒触发一次



    //setWindowTitle("Server");

    // 初始化TCP服务器
    imageServer = new QTcpServer(this);
    bioServer = new QTcpServer(this);

    // 连接信号槽
    connect(imageServer, &QTcpServer::newConnection, this, &MainWindow::newImageConnection);
    connect(bioServer, &QTcpServer::newConnection, this, &MainWindow::newBioConnection);
    //createQSplineSeries();
    createAllCharts();
    ui->IP->setText(getLocalIPv4());//"📡 本机IP地址："



    QTimer *chartUpdateTimer = new QTimer(this);
    connect(chartUpdateTimer, &QTimer::timeout, this, &MainWindow::drawBarChartFromLabels);
    chartUpdateTimer->start(1000);  // 每 1000 毫秒（1 秒）刷新一次
}


/*void MainWindow::updateNextActionCount()
{
    if (currentActionIndex >= actionLineEdits.size())
        currentActionIndex = 0;

    QLineEdit* lineEdit = actionLineEdits[currentActionIndex];
    if (lineEdit)
    {
        bool ok;
        int val = lineEdit->text().toInt(&ok);
        if (!ok) val = 0;
        lineEdit->setText(QString::number(val + 1));
    }

    currentActionIndex++;
}*/

QString MainWindow::getLocalIPv4()//获取本机IP
{
    foreach (const QNetworkInterface &netInterface, QNetworkInterface::allInterfaces())
    {
        if (netInterface.flags().testFlag(QNetworkInterface::IsUp) &&
            netInterface.flags().testFlag(QNetworkInterface::IsRunning) &&
            !netInterface.flags().testFlag(QNetworkInterface::IsLoopBack))
        {
            foreach (const QNetworkAddressEntry &entry, netInterface.addressEntries())
            {
                QHostAddress ip = entry.ip();
                if (ip.protocol() == QAbstractSocket::IPv4Protocol)
                    return ip.toString();  // 找到第一个有效 IPv4
            }
        }
    }
    return "未找到本机IP";
}


void MainWindow::on_TCP_Button_clicked()//启动网络服务
{
    quint16 imagePort = ui->Port_Num->text().toUShort();
    quint16 bioPort = imagePort + 1; // 生理数据端口比图像端口大1

    if (imageServer->isListening()) {
        // 关闭服务
        imageServer->close();
        bioServer->close();
        ui->TCP_Re_TextEdit->appendPlainText("⛔️ 网络服务已关闭");
        ui->TCP_Button->setText("✅开启网络服务");
    } else {
        // 尝试启动服务
        if (!imageServer->listen(QHostAddress::Any, imagePort)) {
            ui->TCP_Re_TextEdit->appendPlainText("⚠️ 图像服务启动失败：" + imageServer->errorString());
        } else if (!bioServer->listen(QHostAddress::Any, bioPort)) {
            imageServer->close();
            ui->TCP_Re_TextEdit->appendPlainText("⚠️ 生理数据服务启动失败：" + bioServer->errorString());
        } else {
            ui->TCP_Re_TextEdit->appendPlainText("✅ 服务已启动，监听端口：" + QString::number(imagePort));
            //ui->TCP_Re_TextEdit->appendPlainText("✅ 生理数据服务已启动，监听端口：" + QString::number(bioPort));
            ui->TCP_Button->setText("⛔️关闭网络服务");
        }
    }
}
/*void MainWindow::newImageConnection()
{
    while (imageServer->hasPendingConnections()) {
        QTcpSocket* socket = imageServer->nextPendingConnection();
        imageClients.append(socket);

        connect(socket, &QTcpSocket::readyRead, this, [=]() {
            QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
            if (!socket) return;

            QByteArray buf = socket->readAll();
            ImagePacket& packet = imagePackets[socket];
            packet.buffer.append(buf);

            // 1. 接收元数据 (8字节: 4字节image_type + 4字节action_flags)
            if (packet.stage == 0 && packet.buffer.size() >= 8) {
                QDataStream metaStream(packet.buffer.left(8));
                metaStream.setByteOrder(QDataStream::BigEndian); // 对应Python的'!'
                metaStream >> packet.imageType >> packet.actionFlags;

                packet.buffer = packet.buffer.mid(8); // 移除已处理的元数据
                packet.stage = 1;

                QString typeDesc = (packet.imageType == 1) ? "驾驶室" :
                                       (packet.imageType == 2) ? "油箱" : "未知";
                ui->TCP_Re_TextEdit->appendPlainText(
                    QString("🟡 图像元数据：类型=%1，标志位=0x%2")
                        .arg(typeDesc)
                        .arg(packet.actionFlags, 8, 16, QLatin1Char('0')).toUpper());
            }

            // 2. 接收图像大小 (4字节)
            if (packet.stage == 1 && packet.buffer.size() >= 4) {
                QDataStream sizeStream(packet.buffer.left(4));
                sizeStream.setByteOrder(QDataStream::BigEndian);
                quint32 size;
                sizeStream >> size;
                packet.imageSize = static_cast<int>(size);

                packet.buffer = packet.buffer.mid(4); // 移除已处理的size
                packet.stage = 2;

                ui->TCP_Re_TextEdit->appendPlainText(
                    QString("📦 图像大小：%1 字节").arg(packet.imageSize));
            }

            // 3. 接收图像数据
            if (packet.stage == 2 && packet.buffer.size() >= packet.imageSize) {
                QByteArray imageBytes = packet.buffer.left(packet.imageSize);
                packet.buffer = packet.buffer.mid(packet.imageSize);

                QImage img;
                img.loadFromData(imageBytes, "JPEG");

                if (!img.isNull()) {
                    //img = img.convertToFormat(QImage::Format_RGB888).rgbSwapped();
                    img = img.convertToFormat(QImage::Format_RGB888);


                    QPixmap pixmap = QPixmap::fromImage(
                        img.scaled(ui->Image_Label->size(), Qt::KeepAspectRatio));

                    if (packet.imageType == 1) {
                        ui->Image_Label->setPixmap(pixmap);
                    } else if (packet.imageType == 2) {
                        ui->Image_Label_2->setPixmap(pixmap);
                        //ui->Image_Label_2->repaint();  // 立即重绘
                    }

                    ui->TCP_Re_TextEdit->appendPlainText("📷 图像接收成功");

                    // 更新动作计数器
                    auto updateCount = [](QLineEdit* lineEdit, bool flag) {
                        if (!lineEdit || !flag) return;
                        bool ok;
                        int val = lineEdit->text().toInt(&ok);
                        if (!ok) val = 0;
                        lineEdit->setText(QString::number(val + 1));
                    };

                    if (packet.imageType == 1) {
                        updateCount(ui->lineEdit_fatugi,   packet.actionFlags & 0x01);
                        updateCount(ui->lineEdit_smok,     packet.actionFlags & 0x02);
                        updateCount(ui->lineEdit_ph,       packet.actionFlags & 0x04);
                        updateCount(ui->lineEdit_drink,    packet.actionFlags & 0x08);
                    } else if (packet.imageType == 2) {
                        updateCount(ui->lineEdit_ws,     packet.actionFlags & 0x01);
                        updateCount(ui->lineEdit_wd,     packet.actionFlags & 0x02);
                        updateCount(ui->lineEdit_zg,     packet.actionFlags & 0x04);
                        updateCount(ui->lineEdit_jd,     packet.actionFlags & 0x08);
                    }
                } else {
                    ui->TCP_Re_TextEdit->appendPlainText("❌ 图像解码失败");
                }

                // 重置状态，准备下一帧
                packet = ImagePacket();
            }
        });

        connect(socket, &QTcpSocket::disconnected, this, [=]() {
            imageClients.removeOne(socket);
            imagePackets.remove(socket);
            socket->deleteLater();
            ui->TCP_Re_TextEdit->appendPlainText("📤 图像客户端已断开");
            updateConnectedNum();
        });

        ui->TCP_Re_TextEdit->appendPlainText("📥 新图像客户端连接");
        updateConnectedNum();
    }
}*/


void MainWindow::newImageConnection()
{
    while (imageServer->hasPendingConnections()) {
        QTcpSocket* socket = imageServer->nextPendingConnection();
        imageClients.append(socket);

        connect(socket, &QTcpSocket::readyRead, this, [=]() {
            QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
            if (!socket) return;

            QByteArray buf = socket->readAll();
            ImagePacket& packet = imagePackets[socket];
            packet.buffer.append(buf);

            while (true) {
                // 1. 接收元数据 (8字节: 4字节image_type + 4字节action_flags)
                if (packet.stage == 0 && packet.buffer.size() >= 8) {
                    QDataStream metaStream(packet.buffer.left(8));
                    metaStream.setByteOrder(QDataStream::BigEndian);
                    metaStream >> packet.imageType >> packet.actionFlags;

                    if (packet.imageType != 1 && packet.imageType != 2) {
                        ui->TCP_Re_TextEdit->appendPlainText("❌ 非法图像类型，丢弃数据");
                        packet = ImagePacket();
                        return;
                    }

                    packet.buffer = packet.buffer.mid(8);
                    packet.stage = 1;

                    QString typeDesc = (packet.imageType == 1) ? "驾驶室" :
                                           (packet.imageType == 2) ? "油箱" : "未知";
                    ui->TCP_Re_TextEdit->appendPlainText(
                        QString("🟡 图像元数据：类型=%1，标志位=0x%2")
                            .arg(typeDesc)
                            .arg(packet.actionFlags, 8, 16, QLatin1Char('0')).toUpper());
                }

                // 2. 接收图像大小 (4字节)
                if (packet.stage == 1 && packet.buffer.size() >= 4) {
                    QDataStream sizeStream(packet.buffer.left(4));
                    sizeStream.setByteOrder(QDataStream::BigEndian);
                    quint32 size;
                    sizeStream >> size;
                    packet.imageSize = static_cast<int>(size);

                    if (packet.imageSize <= 0 || packet.imageSize > 10 * 1024 * 1024) {
                        ui->TCP_Re_TextEdit->appendPlainText(
                            QString("❌ 图像大小异常：%1 字节，丢弃数据").arg(packet.imageSize));
                        packet = ImagePacket();
                        return;
                    }

                    packet.buffer = packet.buffer.mid(4);
                    packet.stage = 2;

                    ui->TCP_Re_TextEdit->appendPlainText(
                        QString("📦 图像大小：%1 字节").arg(packet.imageSize));
                }

                // 3. 接收图像数据
                if (packet.stage == 2 && packet.buffer.size() >= packet.imageSize) {
                    QByteArray imageBytes = packet.buffer.left(packet.imageSize);
                    packet.buffer = packet.buffer.mid(packet.imageSize);

                    QImage img;
                    img.loadFromData(imageBytes, "JPEG");

                    if (!img.isNull()) {
                        QPixmap pixmap = QPixmap::fromImage(
                            img.scaled(ui->Image_Label->size(), Qt::KeepAspectRatio));

                        if (packet.imageType == 1) {
                            ui->Image_Label->setPixmap(pixmap);
                        } else if (packet.imageType == 2) {
                            ui->Image_Label_2->setPixmap(pixmap);
                        }

                        ui->TCP_Re_TextEdit->appendPlainText("📷 图像接收成功");

                        auto updateCount = [](QLineEdit* lineEdit, bool flag) {
                            if (!lineEdit || !flag) return;
                            bool ok;
                            int val = lineEdit->text().toInt(&ok);
                            if (!ok) val = 0;
                            lineEdit->setText(QString::number(val + 1));
                        };

                        if (packet.imageType == 1) {
                            updateCount(ui->lineEdit_fatugi, packet.actionFlags & 0x01);
                            updateCount(ui->lineEdit_smok,   packet.actionFlags & 0x02);
                            updateCount(ui->lineEdit_ph,     packet.actionFlags & 0x04);
                            updateCount(ui->lineEdit_drink,  packet.actionFlags & 0x08);
                        } else if (packet.imageType == 2) {
                            updateCount(ui->lineEdit_ws,     packet.actionFlags & 0x01);
                            updateCount(ui->lineEdit_wd,     packet.actionFlags & 0x02);
                            updateCount(ui->lineEdit_zg,     packet.actionFlags & 0x04);
                            updateCount(ui->lineEdit_jd,     packet.actionFlags & 0x08);
                        }
                    } else {
                        ui->TCP_Re_TextEdit->appendPlainText("❌ 图像解码失败");
                    }

                    packet = ImagePacket();  // 重置状态
                    continue;  // 继续处理下一帧（支持粘包）
                }

                break;  // 数据不足，退出循环
            }
        });

        connect(socket, &QTcpSocket::disconnected, this, [=]() {
            imageClients.removeOne(socket);
            imagePackets.remove(socket);
            socket->deleteLater();
            //ui->TCP_Re_TextEdit->appendPlainText("📤 图像客户端已断开");
            updateConnectedNum();
        });

        ui->TCP_Re_TextEdit->appendPlainText("📥 一个新终端已连接");
        updateConnectedNum();
    }
}

void MainWindow::newBioConnection()
{
    while (bioServer->hasPendingConnections()) {
        QTcpSocket* socket = bioServer->nextPendingConnection();
        bioClients.append(socket);

        connect(socket, &QTcpSocket::readyRead, this, [=]() {
            QByteArray buf = socket->readAll();

            // 生理数据解析
            if (buf.size() >= 14) {
                const uchar* p = reinterpret_cast<const uchar*>(buf.constData());

                if (!((p[0] & 0xFC) || (p[3] & 0xFC))) {
                    int red = (p[0] & 0x03) * 65536 + p[1] * 256 + p[2];
                    int ir = (p[3] & 0x03) * 65536 + p[4] * 256 + p[5];
                    float temp = p[6] + p[7] * 0.0625;
                    int pr = p[8];
                    int spo2 = p[9];
                    int dev_id = p[10] * 256 + p[11];
                    int heart = p[12] * 256 + p[13] - 355;

                    ui->TCP_Re_TextEdit->appendPlainText(
                        QString("🧬 Red=%1 IR=%2 Temp=%3 PR=%4 SPO2=%5 ID=%6 心率=%7")
                            .arg(red).arg(ir).arg(temp)
                            .arg(pr).arg(spo2).arg(dev_id).arg(heart));

                    double timeSec = sampleCount * sampleInterval;
                    redSeries->append(timeSec, red / 10000.0);
                    irSeries->append(timeSec, ir / 10000.0);
                    tempSeries->append(timeSec, temp);
                    prSeries->append(timeSec, pr);
                    spo2Series->append(timeSec, spo2);
                    xinlvSeries->append(timeSec, heart);

                    if (timeSec > 5.0) {
                        QList<QChartView*> views = {
                            ui->RED_PLOT, ui->IR_PLOT, ui->TEMP_PLOT,
                            ui->PR_PLOT, ui->SPO2_PLOT, ui->XL_PLOT
                        };
                        for (QChartView* v : views) {
                            QChart *c = v->chart();
                            QValueAxis *x = qobject_cast<QValueAxis*>(c->axisX());
                            if (x) x->setRange(timeSec - 5.0, timeSec);
                        }
                    }

                    QList<QSplineSeries*> seriesList = {
                        redSeries, irSeries, tempSeries, prSeries, spo2Series, xinlvSeries
                    };
                    for (QSplineSeries* s : seriesList)
                        if (s->count() > 200) s->remove(0);

                    sampleCount++;
                }
            }
        });

        connect(socket, &QTcpSocket::disconnected, this, [=]() {
            bioClients.removeOne(socket);
            socket->deleteLater();
            //ui->TCP_Re_TextEdit->appendPlainText("📤 生理数据客户端已断开");
            updateConnectedNum();
        });

        //ui->TCP_Re_TextEdit->appendPlainText("📥 新生理数据客户端连接");
        updateConnectedNum();
    }
}



QChart* MainWindow::createCharts(QSplineSeries *series, const QString &title, const QString &unit, double yMin, double yMax, const QColor &color)
{
    QChart *chart = new QChart();
    series->setColor(color);                        // 设置曲线颜色
    QPen pen(color);          // 保持你的原始颜色
    pen.setWidth(3);          // 设置线宽，数值越大越粗
    series->setPen(pen);
    series->setPointsVisible(true);
    chart->addSeries(series);
    chart->setTitle(title);
    chart->setTheme(QChart::ChartThemeLight);
    chart->legend()->setVisible(false);
    chart->setBackgroundVisible(false);
    chart->setPlotAreaBackgroundVisible(false);
    chart->layout()->setContentsMargins(0, 0, 0, 0);
    chart->setMargins(QMargins(0, 0, 0, 0));

    QFont font("Microsoft YaHei", 10);
    font.setBold(true);
    chart->setTitleFont(font);

    QValueAxis *axisX = new QValueAxis;
    axisX->setRange(0, 5);
    axisX->setLabelFormat("%.1f s");
    axisX->setTitleText("时间（秒）");
    axisX->setLabelsFont(font);
    axisX->setTitleFont(font);

    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(yMin, yMax);
    axisY->setTitleText(unit);
    axisY->setLabelsFont(font);
    axisY->setTitleFont(font);

    chart->setAxisX(axisX, series);
    chart->setAxisY(axisY, series);

    return chart;
}


void MainWindow::createAllCharts()
{
    redSeries = new QSplineSeries;
    irSeries = new QSplineSeries;
    tempSeries = new QSplineSeries;
    prSeries = new QSplineSeries;
    spo2Series = new QSplineSeries;
    xinlvSeries = new QSplineSeries;

    ui->RED_PLOT->setChart(createCharts(redSeries, "Red", "RED（×10k）", 0, 20, QColor("#e91e63")));     // 洋红
    ui->IR_PLOT->setChart(createCharts(irSeries, "IR", "IR（×10k）", 0, 20, QColor("#3f51b5")));        // 蓝紫
    ui->TEMP_PLOT->setChart(createCharts(tempSeries, "Temp", "温度（℃）", 30, 45, QColor("#ff9800"))); // 橙色
    ui->PR_PLOT->setChart(createCharts(prSeries, "PR", "脉搏", 30, 150, QColor("#4caf50")));            // 绿色
    ui->SPO2_PLOT->setChart(createCharts(spo2Series, "SPO2", "血氧（%）", 0, 100, QColor("#2196f3")));   // 天蓝
    ui->XL_PLOT->setChart(createCharts(xinlvSeries, "XinLv", "心率", 30, 150, QColor("#9c27b0")));      // 紫色
}


void MainWindow::drawBarChartFromLabels()
{
    // 1. 获取数据
    QVector<int> values = {
        ui->lineEdit_fatugi->text().toInt(),
        ui->lineEdit_ph->text().toInt(),
        ui->lineEdit_smok->text().toInt(),
        ui->lineEdit_drink->text().toInt(),
        ui->lineEdit_ws->text().toInt(),
        ui->lineEdit_wd->text().toInt(),
        ui->lineEdit_zg->text().toInt(),
        ui->lineEdit_jd->text().toInt()
    };

    QStringList labels = {
        "疲劳", "玩手机", "抽烟", "喝水",
        "弯腰伸手", "弯腰低头", "左顾右盼", "重复击打"
    };

    // 2. 创建图表
    QChart *chart = new QChart();
    chart->setAnimationOptions(QChart::NoAnimation);
    chart->legend()->setVisible(false);
    chart->setBackgroundVisible(false);
    chart->setPlotAreaBackgroundVisible(false);
    chart->layout()->setContentsMargins(0, 0, 0, 0);
    chart->setMargins(QMargins(0, 0, 0, 0));

    QFont font("Microsoft YaHei", 9);
    font.setBold(true);

    // 3. 创建一个 QBarSet，包含所有值
    QBarSet *set = new QBarSet("报警次数");
    for (int v : values) {
        *set << v;
    }
    set->setLabelFont(font);
    set->setLabelColor(Qt::black);

    // 4. 创建 QBarSeries 并设置标签
    QBarSeries *series = new QBarSeries();
    series->append(set);
    series->setLabelsVisible(true);
    series->setLabelsPosition(QAbstractBarSeries::LabelsOutsideEnd);

    chart->addSeries(series);

    // 5. 设置 X 轴标签
    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(labels);
    axisX->setLabelsFont(font);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);

    // 6. 设置 Y 轴
    int maxValue = *std::max_element(values.begin(), values.end());
    QValueAxis *axisY = new QValueAxis();
    axisY->setRange(0, maxValue + 1);
    axisY->setLabelsFont(font);
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);

    // 7. 显示图表
    ui->Data_Plot->setChart(chart);
    ui->Data_Plot->setRenderHint(QPainter::Antialiasing);
    ui->Data_Plot->setContentsMargins(0, 0, 0, 0);
}




void MainWindow::updateTime()
{
    QDateTime current_date_time = QDateTime::currentDateTime();
    QString current_date = current_date_time.toString("yyyy.MM.dd hh:mm:ss");
    ui->label_Time->setText(current_date);
}


void MainWindow::on_pushButton_clicked()
{
    // 1. 清空图表数据
    ui->Data_Plot->chart()->removeAllSeries();

    // 重新创建空图表
    QChart *chart = new QChart();
    chart->setAnimationOptions(QChart::NoAnimation);
    chart->legend()->setVisible(false);
    ui->Data_Plot->setChart(chart);

    // 2. 清空图像显示
    ui->Image_Label->clear();
    ui->Image_Label_2->clear();

    // 3. 清空所有计数器
    QList<QLineEdit*> lineEdits = {
        ui->lineEdit_fatugi, ui->lineEdit_ph, ui->lineEdit_smok, ui->lineEdit_drink,
        ui->lineEdit_ws, ui->lineEdit_wd, ui->lineEdit_zg, ui->lineEdit_jd
    };

    for (QLineEdit* lineEdit : lineEdits) {
        lineEdit->clear();
    }

    // 4. 可选：重置生理数据图表
    redSeries->clear();
    irSeries->clear();
    tempSeries->clear();
    prSeries->clear();
    spo2Series->clear();
    xinlvSeries->clear();

    // 5. 更新日志
    ui->TCP_Re_TextEdit->appendPlainText("🔄 所有数据和图像已清空");
}

void MainWindow::updateConnectedNum()
{

    //ui->lcdNumber->display(QString::number(imageClients.size() + bioClients.size()));
    ui->lcdNumber->display(1);
}

MainWindow::~MainWindow()
{
    delete ui;
}



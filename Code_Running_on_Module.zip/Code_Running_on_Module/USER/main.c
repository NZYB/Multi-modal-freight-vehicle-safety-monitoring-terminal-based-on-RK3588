/*************************************************************************************
STM32F103-30102:
	VCC<->3.3V
	GND<->GND
	SCL<->PB7
	SDA<->PB8
	IM<->PB9
0.96inch OLED :
	VCC<->3.3V
	GND<->GND
	SCL<->PA5
	SDA<->PA6
	RST<->PA3
	DC<->PA4
	CS<->PA2
USB-TTL:
	5V<->5V
	GND<->GND
	RXD<->PA9
	TXD<->PA10
**************************************************************************************/
#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "max30102.h" 
#include "myiic.h"
#include "algorithm.h"
#include "oled.h"
#include "esp8266.h"
#include "usart3.h"
#include "timer.h"
#include "string.h"
#include "eeprom.h"


#define OW_DEV_ADD	 		0xA0
#define OR_DEV_ADD  		0xA1

uint32_t aun_ir_buffer[500]; //IR LED sensor data
int32_t n_ir_buffer_length;    //data length
uint32_t aun_red_buffer[500];    //Red LED sensor data
int32_t n_sp02; //SPO2 value
int8_t ch_spo2_valid;   //indicator to show if the SP02 calculation is valid
int32_t n_heart_rate;   //heart rate value
int8_t  ch_hr_valid;    //indicator to show if the heart rate calculation is valid

uint8_t uch_dummy;
uint8_t DATAZ[8]={0X01,0X02,0X03,0X04,0X05,0x06,0x07,0x08};
uint8_t DATA1[10];
char ip_buff[20];
char rx_strbuf[20];
uint8_t CH2O_flag;
extern uint8_t receivedDataAvailable;
extern char Usart1_R_Buff[100];	//����1���ݽ��ջ����� 
extern u8 Usart1_R_State;						//����1����״̬
extern u16 Usart1_R_Count;						//��ǰ�������ݵ��ֽ���
extern bool ack_err_flag;

#define MAX_BRIGHTNESS 255
//#define ipsize

void dis_DrawCurve(u32* data,u8 x);
int HextoChar(uint8_t *u8, uint8_t len, char *ch);
static void hex_to_str(uint8_t *source, uint32_t len, uint8_t *target);
uint8_t hex_2_char(uint8_t *src);
int main(void)
{ 
	//variables to calculate the on-board LED brightness that reflects the heartbeats
	uint32_t un_min, un_max, un_prev_data;  
	int i;
	int b;
	int c;
	int32_t n_brightness;
	float f_temp;
	u8 temp_num=0;
	u8 rxlength;
	u8 temp[8];//ԭ��Ϊ6  �ĳ�8
	u8 str[100];
	u8 dis_hr=0,dis_spo2=0;
	u8 p,n;
	char ipbuffer[20]; // ������
  char iptempBuffer[10]; // ��ʱ������
	NVIC_Configuration();
	delay_init();	    	 //��ʱ������ʼ��	  
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200
	LED_Init();
	I2CO_Init();
	OSDA_IN();//OSDAΪ����ģʽ
	//OLED
//	OLED_Init();
//	OLED_ShowString(0,0," initializing  ",16);
//	OLED_Refresh_Gram();//������ʾ��OLED	 
  ack_err_flag = 0;
	max30102_init();
	
	
//					for(c=0; c<8; c++)
//			{
//							//p=Usart1_R_Buff[c];
//			    //read_RAM_ptr++;
//             //if(p != 0xFF)
//			 p=DATAZ[c] ;    
//				OwriteaByte(0x0000+c,p);
//			delay_ms(10);
//			}
//			
//				   for (c=0; c<8; c++)
//			{
//			//    m = *read_RAM_ptr;
//			//    read_RAM_ptr++;
//			    n = OreadaByte(0x0000+c);
//				Usart_SendByte( USART1, n);
//			delay_ms(10);
//			}
  ESP8266_Init ();
	

	printf("\r\n MAX30102  init  \r\n");
	ESP8266_AP_Mode_Test();
	TIM2_Int_Init(999,7199);
	un_min=0x3FFFF;
	un_max=0;
	
//while(1)
//{
//	
//		if(Usart1_R_State == 1)//һ֡���ݽ������
//		{
//			Usart_SendArray(USART1,(u8 *)Usart1_R_Buff, Usart1_R_Count);//USART1�������ݻ���������(���͸ս�����ɵ�һ֡����)
//			Usart1_R_State =0;
//			Usart1_R_Count =0;
//		}

////	if (receivedDataAvailable)
////	{
////		 rxlength=rx_strbuf[0];
////		for(b=0;b<rxlength+1;b++)
////					{
////					ip_buff[b]=rx_strbuf[b+1];
////					}
////				receivedDataAvailable=0;
////				Usart_SendString(USART1,ip_buff);
////	}
//	
//	
//	
////for (u8 i =0; i < rx_strbuf[0]+1; i++) 
////					{
////            rx_strbuf[i] = 0;
////					}

////	max30102_FIFO_ReadBytes(REG_FIFO_DATA,temp);
////		delay_ms(10);
////		max30102_Bus_Write(0x21,0x01);
////				delay_ms(10);
////		temp[6]=max30102_Bus_Read(0x1F);
////				delay_ms(10);
////		temp[7]=max30102_Bus_Read(0x20);
////				delay_ms(10);
////	delay_ms(100);
////			Usart_SendArray( USART1, temp, 8);
////			Usart_SendArray( USART3, temp, 8);
//}
	
	//Դ����***
	n_ir_buffer_length=500; //buffer length of 100 stores 5 seconds of samples running at 100sps
  //read the first 500 samples, and determine the signal range
  for(i=0;i<n_ir_buffer_length;i++)
    {
   while(MAX30102_INT==1);   //wait until the interrupt pin asserts
		max30102_FIFO_ReadBytes(REG_FIFO_DATA,temp);
		aun_red_buffer[i] =  (long)((long)((long)temp[0]&0x03)<<16) | (long)temp[1]<<8 | (long)temp[2];    // Combine values to get the actual number
		aun_ir_buffer[i] = (long)((long)((long)temp[3] & 0x03)<<16) |(long)temp[4]<<8 | (long)temp[5];   // Combine values to get the actual number
            
		//�¼Ӳ��ִ���
		//wr_max30102_one_data(0xae,0x21,0x01);       // 0X21��ַB0λTEMP_EN��1
//		max30102_Bus_Write(0x21,0x01);
//				delay_ms(10);
//		temp[6]=max30102_Bus_Read(0x1F);
//				delay_ms(10);
//		temp[7]=max30102_Bus_Read(0x20);
//				delay_ms(10);
        if(un_min>aun_red_buffer[i])
            un_min=aun_red_buffer[i];    //update signal min
        if(un_max<aun_red_buffer[i])
            un_max=aun_red_buffer[i];    //update signal max
    }
		
//			Usart_SendArray( USART1, temp, 8);
//			Usart_SendArray( USART3, temp, 8);
//			Usart_SendArray( USART1, DATAZ, 8);
//			Usart_SendArray( USART3, DATAZ, 8);

	un_prev_data=aun_red_buffer[i];
	//calculate heart rate and SpO2 after first 500 samples (first 5 seconds of samples)
 maxim_heart_rate_and_oxygen_saturation(aun_ir_buffer, n_ir_buffer_length, aun_red_buffer, &n_sp02, &ch_spo2_valid, &n_heart_rate, &ch_hr_valid); 
	
	while(1)
	{
		i=0;
        un_min=0x3FFFF;
        un_max=0;
		//dumping the first 100 sets of samples in the memory and shift the last 400 sets of samples to the top
        for(i=100;i<500;i++)
        {
            aun_red_buffer[i-100]=aun_red_buffer[i];
            aun_ir_buffer[i-100]=aun_ir_buffer[i];
            
            //update the signal min and max
            if(un_min>aun_red_buffer[i])
            un_min=aun_red_buffer[i];
            if(un_max<aun_red_buffer[i])
            un_max=aun_red_buffer[i];
        }
		//take 100 sets of samples before calculating the heart rate.
        for(i=400;i<500;i++)
        {
            un_prev_data=aun_red_buffer[i-1];
            while(MAX30102_INT==1);
            max30102_FIFO_ReadBytes(REG_FIFO_DATA,temp);
			aun_red_buffer[i] =  (long)((long)((long)temp[0]&0x03)<<16) | (long)temp[1]<<8 | (long)temp[2];    // Combine values to get the actual number
			aun_ir_buffer[i] = (long)((long)((long)temp[3] & 0x03)<<16) |(long)temp[4]<<8 | (long)temp[5];   // Combine values to get the actual number
				
//    max30102_Bus_Write(0x21,0x01);
//				delay_ms(5);
//		temp[6]=max30102_Bus_Read(0x1F);
//				delay_ms(5);
//		temp[7]=max30102_Bus_Read(0x20);

		
            if(aun_red_buffer[i]>un_prev_data)
            {
                f_temp=aun_red_buffer[i]-un_prev_data;
                f_temp/=(un_max-un_min);
                f_temp*=MAX_BRIGHTNESS;
                n_brightness-=(int)f_temp;
                if(n_brightness<0)
                    n_brightness=0;
            }
            else
            {
                f_temp=un_prev_data-aun_red_buffer[i];
                f_temp/=(un_max-un_min);
                f_temp*=MAX_BRIGHTNESS;
                n_brightness+=(int)f_temp;
                if(n_brightness>MAX_BRIGHTNESS)
                    n_brightness=MAX_BRIGHTNESS;
            }
			//send samples and calculation result to terminal program through UART
			if(ch_hr_valid == 1 && n_heart_rate<120)//**/ ch_hr_valid == 1 && ch_spo2_valid ==1 && n_heart_rate<120 && n_sp02<101
			{
				dis_hr = n_heart_rate;
				dis_spo2 = n_sp02;
			}
			else
			{
				dis_hr = 0;
				dis_spo2 = 0;
			}
		
			
			
			//	printf("HR=%i, ", n_heart_rate); 
			//	printf("HRvalid=%i, ", ch_hr_valid);
			//	printf("SpO2=%i, ", n_sp02);
			//	printf("SPO2Valid=%i\r\n", ch_spo2_valid);
	
		//	Usart_SendString( macESP8266_USARTx,"1");
			//Usart_SendArray( USART1, temp, 8);
			//Usart_SendArray( USART3, temp, 8);
		}
//				if(CH2O_flag)
//		{
//		max30102_FIFO_ReadBytes(REG_FIFO_DATA,DATA1);
//		delay1(50);
//		max30102_Bus_Write(0x21,0x01);
//		delay1(10);
//		DATA1[6]=max30102_Bus_Read(0x1F);
//		delay1(10);
//		DATA1[7]=max30102_Bus_Read(0x20);
//		delay1(10);
//		DATA1[8]=dis_hr;
//		DATA1[9]=dis_spo2;
//		Usart_SendArray( USART1, DATA1, 10);
//		Usart_SendArray( USART3, DATA1, 10);	
//	CH2O_flag=0;
//				}
//		
				
//				
//	if (receivedDataAvailable)
//	{
//		 rxlength=rx_strbuf[0];
//		for(b=0;b<rxlength+1;b++)
//					{
//					ip_buff[b]=rx_strbuf[b+1];
//					}
//				receivedDataAvailable=0;
//				Usart_SendString(USART1,ip_buff);
//	}
//	
//				
				if(Usart1_R_State == 1)//һ֡���ݽ������
		{
					for(c=0; c<Usart1_R_Count; c++)
			{
						p=Usart1_R_Buff[c];
						OwriteaByte(0x0000+c,p);
						delay_ms(10);
			}
				   for (c=0; c<Usart1_R_Count; c++)
			{
			//    m = *read_RAM_ptr;
			//    read_RAM_ptr++;
			    n = OreadaByte(0x0000+c);
					ipbuffer[c]=n;
					Usart_SendByte( USART1, n);
					delay_ms(10);
			}
			ipbuffer[Usart1_R_Count-2]=0;	
			ipbuffer[Usart1_R_Count-1]=0;
	  while ( ! ESP8266_Link_Server(enumTCP,ipbuffer,"8085",5)){;}


//		 ipbuffer[0]='1';
//	   ipbuffer[1]='2';
			
	//		HextoChar(Usart1_R_Buff, Usart1_R_Count-2, ipbuffer);
//	hex_to_str(uint8_t *source, uint32_t len, uint8_t *target)	
	//	Usart1_R_Buff[Usart1_R_Count-1]= 0;
			
//while ( ! ESP8266_Link_Server(enumTCP,Usart1_R_Buff,"8085",5)){;}
	//	Usart_SendArray(USART1,(u8 *)Usart1_R_Buff, Usart1_R_Count);//USART1�������ݻ���������(���͸ս�����ɵ�һ֡����)
//		ipbuffer[0] = '\0';
//		for (c=0; c<Usart1_R_Count-2; c++) 
//		{
//        sprintf(iptempBuffer,"%x",Usart1_R_Buff[c]); // ��Ԫ��ת��Ϊ�ַ���
//        strcat(ipbuffer, iptempBuffer); // ���ַ������ӵ�buffer��
//    }
					
//		ipbuffer[1]=Usart1_R_Buff[c];
		//	Usart_SendArray(USART1,(u8 *)ipbuffer, Usart1_R_Count-2);//USART1�������ݻ���������(���͸ս�����ɵ�һ֡����)

			//printf("%s",ipbuffer); 
			Usart1_R_State =0;
			Usart1_R_Count =0;
		}
	
////		ipbuffer[0] = '\0';
////		for (c=0; c< Usart1_R_Count-2;c++) 
////		{
////        sprintf(iptempBuffer, "%d", Usart1_R_Buff[c]); // ��Ԫ��ת��Ϊ�ַ���
////        strcat(ipbuffer, iptempBuffer); // ���ַ������ӵ�buffer��
////    }
		
		
     maxim_heart_rate_and_oxygen_saturation(aun_ir_buffer, n_ir_buffer_length, aun_red_buffer, &n_sp02, &ch_spo2_valid, &n_heart_rate, &ch_hr_valid);
		
		//��ʾˢ��
		LED0=0;
//		if(dis_hr == 0 && dis_spo2 == 0)  //**dis_hr == 0 && dis_spo2 == 0
//		{
//			sprintf((char *)str,"HR:--- SpO2:--- ");//**HR:--- SpO2:--- 
//		}
//		else{
//			sprintf((char *)str,"HR:%3d SpO2:%3d ",dis_hr,dis_spo2);//**HR:%3d SpO2:%3d 
//		}
//		OLED_ShowString(0,0,str,16);
//		OLED_Fill(0,23,127,63,0);
    //  ESP8266_SendString ( ENABLE,n_heart_rate,1, Single_ID_0 );               //ͨ��͸��ģʽ ������Ϣ��ԭ����

		//������ϣ���������
	//	dis_DrawCurve(aun_red_buffer,20);
	//	dis_DrawCurve(aun_ir_buffer,0);
	//	OLED_Refresh_Gram();//������ʾ��OLED	 
	}
//***Դ����
}

void dis_DrawCurve(u32* data,u8 x)
{
	u16 i;
	u32 max=0,min=262144;
	u32 temp;
	u32 compress;
	
	for(i=0;i<128*2;i++)
	{
		if(data[i]>max)
		{
			max = data[i];
		}
		if(data[i]<min)
		{
			min = data[i];
		}
	}
	
	compress = (max-min)/20;
	
	for(i=0;i<128;i++)
	{
		temp = data[i*2] + data[i*2+1];
		temp/=2;
		temp -= min;
		temp/=compress;
		if(temp>20)temp=20;
		OLED_DrawPoint(i,63-x-temp,1);
	}
}


int HextoChar(uint8_t *u8, uint8_t len, char *ch)

{

uint8_t tmp = 0x00;
	int i;
	int j;
for ( i = 0; i < len; i++)

{
for (j = 0; j < 2; j++)
{
tmp = (*(u8 + i) >> 4) * (1 - j) + (*(u8 + i) & 0x0F) * j;
if (tmp >= 0 && tmp <= 9)
{
ch[2 * i + j] = tmp + '0';

}

else if (tmp >= 0x0A && tmp <= 0x0F)

{

ch[2 * i + j] = tmp - 0x0A + 'A';

}

}

}

return 0;

}

static void hex_to_str(uint8_t *source, uint32_t len, uint8_t *target)
{
    uint8_t ddl, ddh;
    uint32_t i;

    for (i = 0; i < len; i++)
    {
        ddh = ('0' + source[i] / 16);
        ddl = ('0' + source[i] % 16);

        if (ddh > '9')
            ddh = (ddh + ('a' - '9' - 1));
        if (ddl > '9')
            ddl = (ddl + ('a' - '9' - 1));

        target[i * 2] = ddh;
        target[i * 2 + 1] = ddl;
    }
    target[len] = '\0';
}
uint8_t hex_2_char(uint8_t *src)
{
    uint8_t desc;

    if((*src >= 0) && (*src <= 9))
        desc = *src + 0x30;
    else if((*src >= 0xA) && (*src <= 0xF))
        desc = *src + 0x37;
    
    return desc;
}


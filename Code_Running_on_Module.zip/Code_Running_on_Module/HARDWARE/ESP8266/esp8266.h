#ifndef  __BSP_ESP8266_H
#define	 __BSP_ESP8266_H



#include "stm32f10x.h"
//#include "common.h"
#include <stdio.h>
#include <stdbool.h>


#if defined ( __CC_ARM   )
#pragma anon_unions
#endif



/******************************* ESP8266 �������Ͷ��� ***************************/
typedef enum {
    STA,
    AP,
    STA_AP
} ENUM_Net_ModeTypeDef;


typedef enum {
    enumTCP,
    enumUDP,
} ENUM_NetPro_TypeDef;


typedef enum {
    Multiple_ID_0 = 0,
    Multiple_ID_1 = 1,
    Multiple_ID_2 = 2,
    Multiple_ID_3 = 3,
    Multiple_ID_4 = 4,
    Single_ID_0 = 5,
} ENUM_ID_NO_TypeDef;


typedef enum {
    OPEN = 0,
    WEP = 1,
    WPA_PSK = 2,
    WPA2_PSK = 3,
    WPA_WPA2_PSK = 4,
} ENUM_AP_PsdMode_TypeDef;



/******************************* ESP8266 �ⲿȫ�ֱ������� ***************************/
#define RX_BUF_MAX_LEN     1024                                     //�����ջ����ֽ���

extern struct  STRUCT_USARTx_Fram                                  //��������֡�Ĵ����ṹ��
{
    char  Data_RX_BUF [ RX_BUF_MAX_LEN ];														 //���ݻ�����

    union {																													 //������ ��15λ�������ݳ��ȣ����λΪ������ɱ�־
        __IO u16 InfAll;
        struct {
            __IO u16 FramLength       : 15;                              // 14:0   ���ݳ���
            __IO u16 FramFinishFlag   : 1;                               // 15     һ�����ݽ�����ɱ�־
        } InfBit;
    };

} strEsp8266_Fram_Record;



/******************************** ESP8266 �������Ŷ��� ***********************************/
#define      macESP8266_CH_PD_APBxClock_FUN                   RCC_APB2PeriphClockCmd
#define      macESP8266_CH_PD_CLK                             RCC_APB2Periph_GPIOB
#define      macESP8266_CH_PD_PORT                            GPIOB
#define      macESP8266_CH_PD_PIN                             GPIO_Pin_3

#define      macESP8266_RST_APBxClock_FUN                     RCC_APB2PeriphClockCmd
#define      macESP8266_RST_CLK                               RCC_APB2Periph_GPIOB
#define      macESP8266_RST_PORT                              GPIOB
#define      macESP8266_RST_PIN                               GPIO_Pin_4



#define      macESP8266_USART_BAUD_RATE                       115200

#define      macESP8266_USARTx                                USART3
#define      macESP8266_USART_APBxClock_FUN                   RCC_APB1PeriphClockCmd
#define      macESP8266_USART_CLK                             RCC_APB1Periph_USART3
#define      macESP8266_USART_GPIO_APBxClock_FUN              RCC_APB2PeriphClockCmd
#define      macESP8266_USART_GPIO_CLK                        RCC_APB2Periph_GPIOB
#define      macESP8266_USART_TX_PORT                         GPIOB
#define      macESP8266_USART_TX_PIN                          GPIO_Pin_10
#define      macESP8266_USART_RX_PORT                         GPIOB
#define      macESP8266_USART_RX_PIN                          GPIO_Pin_11
#define      macESP8266_USART_IRQ                             USART3_IRQn
#define      macESP8266_USART_INT_FUN                         USART3_IRQHandler



/*********************************************** ESP8266 �����궨�� *******************************************/
#define     macESP8266_Usart( fmt, ... )           USART_printf ( macESP8266_USARTx, fmt, ##__VA_ARGS__ )
#define     macPC_Usart( fmt, ... )                printf ( fmt, ##__VA_ARGS__ )

#define     macESP8266_CH_ENABLE()                 GPIO_SetBits ( macESP8266_CH_PD_PORT, macESP8266_CH_PD_PIN )
#define     macESP8266_CH_DISABLE()                GPIO_ResetBits ( macESP8266_CH_PD_PORT, macESP8266_CH_PD_PIN )

#define     macESP8266_RST_HIGH_LEVEL()            GPIO_SetBits ( macESP8266_RST_PORT, macESP8266_RST_PIN )
#define     macESP8266_RST_LOW_LEVEL()             GPIO_ResetBits ( macESP8266_RST_PORT, macESP8266_RST_PIN )



/********************************** �û���Ҫ���õĲ��� AP ģʽ **********************************/
#define   macUser_ESP8266_BulitApSsid         "8266AP"      //Ҫ�������ȵ������
#define   macUser_ESP8266_BulitApEcn           WPA_WPA2_PSK               //Ҫ�������ȵ�ļ��ܷ�ʽ
#define   macUser_ESP8266_BulitApPwd           "12345678"         //Ҫ�������ȵ����Կ

#define   macUser_ESP8266_TcpServer_IP         "192.168.4.2"      //������������IP��ַ
#define   macUser_ESP8266_TcpServer_Port       "8080"             //�����������Ķ˿�

#define   macUser_ESP8266_TcpServer_OverTime   "1800"             //��������ʱʱ�䣨��λ���룩


/********************************** �û���Ҫ���õĲ��� Station ģʽ**********************************/
#define      macUser_ESP8266_ApSsid                       "238"              //Ҫ���ӵ��ȵ������   ģ��ֻ������2.4G����
#define      macUser_ESP8266_ApPwd                        "lilinlaoshi"           //Ҫ���ӵ��ȵ����Կ

#define      macUser_ESP8266_TcpServer_IP1                 "192.168.43.1"       //Ҫ���ӵķ������� IP
#define      macUser_ESP8266_TcpServer_Port               "8080"               //Ҫ���ӵķ������Ķ˿�

/********************************** �û���Ҫ���õĲ��� Station ģʽ**********************************/
//#define      macUser_ESP8266_ApSsid                       "enbiens"              //Ҫ���ӵ�wif������   ģ��ֻ������2.4G����
//#define      macUser_ESP8266_ApPwd                        "EB88858804"           //Ҫ���ӵ�wifi����Կ

//#define      macUser_ESP8266_TcpServer_IP                 "192.168.124.3"        //Ҫ���ӵ��Ե� IP
//#define      macUser_ESP8266_TcpServer_Port               "8080"                 //Ҫ���ӵ��ԵĶ˿�

/********************************** �û���Ҫ���õĲ��� Station ģʽ**********************************/
//#define      macUser_ESP8266_ApSsid                       "enbiens"              //Ҫ���ӵ�wif������   ģ��ֻ������2.4G����
//#define      macUser_ESP8266_ApPwd                        "EB88858804"           //Ҫ���ӵ�wifi����Կ

//#define      yuanziyun_DeviceID                    "61212332528032817648"        //Ҫ���ӵ��Ե� IP
//#define      yuanziyun_DevicePassWord              "12345678"                    //Ҫ���ӵ��ԵĶ˿�



/****************************************** ESP8266 �������� ***********************************************/
void                     ESP8266_Init                        ( void );
void                     ESP8266_Rst                         ( void );
bool                     ESP8266_Cmd                         ( char * cmd, char * reply1, char * reply2, u32 waittime );
void                     ESP8266_AT_Test                     ( void );
bool                     ESP8266_Net_Mode_Choose             ( ENUM_Net_ModeTypeDef enumMode );
bool                     ESP8266_JoinAP                      ( char * pSSID, char * pPassWord );
bool                     ESP8266_BuildAP                     ( char * pSSID, char * pPassWord, ENUM_AP_PsdMode_TypeDef enunPsdMode );
bool                     ESP8266_Enable_MultipleId           ( FunctionalState enumEnUnvarnishTx );
bool                     ESP8266_Link_Server                 ( ENUM_NetPro_TypeDef enumE, char * ip, char * ComNum, ENUM_ID_NO_TypeDef id );
bool                     ESP8266_StartOrShutServer           ( FunctionalState enumMode, char * pPortNum, char * pTimeOver );
uint8_t                  ESP8266_Get_LinkStatus              ( void );
uint8_t                  ESP8266_Get_IdLinkStatus            ( void );
uint8_t                  ESP8266_Inquire_ApIp                ( char * pApIp, uint8_t ucArrayLength );
bool                     ESP8266_UnvarnishSend               ( void );
void                     ESP8266_ExitUnvarnishSend           ( void );
bool                     ESP8266_SendString                  ( FunctionalState enumEnUnvarnishTx, char * pStr, u32 ulStrLength, ENUM_ID_NO_TypeDef ucId );
char *                   ESP8266_ReceiveString               ( FunctionalState enumEnUnvarnishTx );


void                     Esp8266Usart_SendArray              ( USART_TypeDef * pUSARTx, uint8_t *array, uint16_t num);
void                     Esp8266Usart_SendByte               ( USART_TypeDef * pUSARTx, uint8_t ch);



void ESP8266_AP_Mode_Test(void);

uint8_t                  ESP8266_CWLIF                       ( char * pStaIp );
uint8_t                  ESP8266_CIPAP                       ( char * pApIp );

#endif



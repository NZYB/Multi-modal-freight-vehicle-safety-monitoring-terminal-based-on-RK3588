
#include "eeprom.h"
#include "sys.h"
#include "stm32f10x.h"
#include "stdbool.h"
#include "stdio.h"
#include "string.h"



#define OSCL_H()          GPIO_SetBits(GPIOA, GPIO_Pin_7)
#define OSCL_L()          GPIO_ResetBits ( GPIOA, GPIO_Pin_7 )
#define OSDA_H()          OSDA_IN()//���� 
#define OSDA_L()          GPIO_ResetBits(GPIOA, GPIO_Pin_8)

#define OSDA_READ()       PAin(8)//���� 

#define OW_DEV_ADD	 		0xA0
#define OR_DEV_ADD  		0xA1

bool ack_err_flag;

//�������е�delay��Ҫ����һ�� 


/************************************************* Output I2C write and read functions *****************************************/
void I2COStart(void) 
{ 

 //OSDA_OUT();
	 OSDA_H();
	 OSCL_H();
 delay2(50);
 OSDA_OUT();//�¼�
	OSDA_L();
 delay2(50);
 OSCL_L();
 delay2(50);
} 

void I2COStop(void) 
{ 
	 delay2(50);
	 OSDA_L();
   delay2(50);
   OSCL_H(); 
	 delay2(50);
	 OSDA_H();
} 

void I2COAck() 
{ 	
	 OSCL_L();
   delay2(50);
   OSDA_L();
   delay2(50);    
	 OSCL_H();
   delay2(50);
	 OSCL_L();
	 delay2(50);
    /*OSDA = 1; */
} 

void I2CONoAck() 
{ 
   OSDA_H();
	 delay2(50);
	 OSCL_H();
   delay2(50);
	 OSCL_L();
   delay2(50);
} 

u8 I2COTestAck(void) 
{ 
    uint8_t ErrorBit; 
	
	 OSCL_L();
   delay2(50);
   OSDA_H();
   //OSDA_IN();
	 delay2(50);
	 OSCL_H();
   delay2(50); 
    ErrorBit = OSDA_READ();         	/* 0 for ask; 1 for noack */
    if (OSDA_READ() == 1)
    {
        ack_err_flag = 1;
    }
   delay2(50);
	  OSCL_L();
   delay2(50);
	  //OSDA_OUT();
    OSDA_H();
		OSDA_OUT();
    return(ErrorBit);
} 



/************* write one byte to I2C ******************************/
void I2COWrite8Bit(u8 data) 
{ 
      u8 i; 
  	  OSDA_OUT();     /*Change SDA direction to output */
    /*SCL must be at low level */
    
    for(i = 0; i < 8; i++) 
      { 
         delay2(50);
	        OSCL_L();
         delay2(50);
          if(data & 0x80) 
              {OSDA_H();} 
          else 
              {
							OSDA_OUT();  
							OSDA_L();} 
         delay2(50);
	        OSCL_H();
         delay2(50);
          data = data << 1; 
         delay2(50);
      } 
} 


/******************** read one byte from  I2C *******************************/ 
u8 I2CORead8Bit(void) 
{ 
    u8 i, rbyte = 0; 
         
    OSDA_IN();/*change SDA direction to input */
	
    for(i = 0; i < 8; i++) 
    {
	      OSCL_H();
        delay2(50);
        rbyte <<= 1; 
        if(OSDA_READ()) 
        {rbyte  |= 0x01; } 
        else 
        {rbyte &= 0xFE;} 
	      OSCL_L();
        delay2(50);
    } 
    
       OSDA_OUT();     /*change SDA direction to output */
   
    return (rbyte); 
} 

/*****************************  OTP write one byte ***************************/
void OwriteaByte(uint16_t DataAddr,u8 Data)
{ 
	u8 DataAddrH,DataAddrL;
	DataAddrL=(u8)(DataAddr&0x00FF); 
	DataAddr>>=8;
	DataAddrH=(u8)(DataAddr&0x00FF); 
	
    I2COStart();
    
    I2COWrite8Bit(OW_DEV_ADD);
    I2COTestAck();
	
    I2COWrite8Bit(DataAddrH); 
    I2COTestAck();   
	
    I2COWrite8Bit(DataAddrL); 
    I2COTestAck();
    
    I2COWrite8Bit(Data);	
    I2COTestAck();
    
	I2COStop();
	
	delay2(5000);    /* wait for OTP write time end */
} 

/*********************** OTP read one byte ********************************/
u8 OreadaByte(uint16_t DataAddr)
{   
	char Data;
	u8 DataAddrH;
	u8 DataAddrL;
	
	DataAddrL=(u8)(DataAddr&0x00FF);
	DataAddr>>=8;
	DataAddrH=(u8)(DataAddr&0x00FF);
	
    I2COStart(); 
	    I2COWrite8Bit(OW_DEV_ADD); 
    I2COTestAck();   
	
//    I2COWrite8Bit(OW_DEV_ADD);
//    I2COTestAck(); 
//	  
    I2COWrite8Bit(DataAddrH); 
    I2COTestAck();
    
    I2COWrite8Bit(DataAddrL); 
    I2COTestAck();  	
    
  I2COStart();    /* repeated start condition */
////	
    I2COWrite8Bit(OR_DEV_ADD); 
    I2COTestAck();   
    Data = I2CORead8Bit(); 
		
    I2CONoAck(); 
	
    I2COStop();
    
    return (Data);
} 

/********************************************************************************************************
** :IIC1���ų�ʼ��  
**:IIC1 	PB6:SDA
					PB7:SCL
********************************************************************************************************/
void I2CO_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

  //GPIOA1
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��PA,PD�˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;				 //LED0-->PA.8 �˿�����
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
	
 GPIO_Init(GPIOA, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOA.8
	OSCL_H();
}


void OSDA_OUT(void)
{
		GPIO_InitTypeDef  GPIO_InitStructure;
	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��PA,PD�˿�ʱ��
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;				 //LED0-->PA.8 �˿�����
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOA, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOA.8
	
}

void OSCL_OUT(void)
{
	
		GPIO_InitTypeDef  GPIO_InitStructure;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��PA,PD�˿�ʱ��
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;				 //LED0-->PA.8 �˿�����
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOA, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOA.8
	
}

void OSDA_IN(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��PA,PD�˿�ʱ��
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;				 //LED0-->PA.8 �˿�����
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOA, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOA.8
}


void OSCL_IN(void)
{
	 GPIO_InitTypeDef  GPIO_InitStructure;
 
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);	 //ʹ��PA,PD�˿�ʱ��
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;				 //LED0-->PA.8 �˿�����
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOA, &GPIO_InitStructure);					 //�����趨������ʼ��GPIOA.8
}

/*************************************************************************
* Function Name          : delay(u16 number)
* Description            : normal delay function 
* Input                  : u16 number
* Output                 : None
* Return                 : None
**************************************************************************/
void delay2(u16 number)
{
	u16 i;
	for (i=0; i<number; i++)
	{
	    //__NOP();
	}
}



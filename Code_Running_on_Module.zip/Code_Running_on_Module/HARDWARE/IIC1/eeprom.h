#ifndef  __EEPROM_H
#define	 __EEPROM_H
#include "stm32f10x.h"


void I2COStart(void) ;
void I2COStop(void) ;
void I2COAck(void) ;
void I2CONoAck(void) ;
u8 I2COTestAck(void) ;
void I2COWrite8Bit(u8 data) ;
u8 I2CORead8Bit(void) ;
void OwriteaByte(u16 DataAddr,u8 Data);
u8 OreadaByte(u16 DataAddr);

void delay2(u16 number);

void I2CO_Init(void);

void OSCL_OUT(void);
void OSDA_OUT(void);
void OSDA_IN(void);
























#endif